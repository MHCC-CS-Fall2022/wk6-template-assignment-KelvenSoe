// FILE: tbag.h 
// AUTHOR: Kelven Soe
// TEMPLATE CLASS PROVIDED:
//   tbag<Item> (a collection of items; each item may appear multiple times)
//
// TYPEDEFS for the tbag<Item> template class:
//   tbag<Item>::value_type
//     This is the Item type from the template parameter.
//     It is the data type of the items in the tbag. It may be any 
//     of the C++ built-in types (int, char, etc.), or a class with a default
//     constructor, a copy constructor, an assignment
//     operator, and a test for equality (x == y).
//
//   tbag<Item>::size_type
//     This is the data type of any variable that keeps track of how many items
//     are in a tbag
//   
// CONSTRUCTOR for the tbag<Item> class:
//   tbag( )
//     Postcondition: The tbag is empty.
//
// MODIFICATION MEMBER FUNCTIONS for the tbag<Item> class:
//   size_type erase(const Item& target)
//     Postcondition: All copies of target have been removed from the tbag.
//     The return value is the number of copies removed (which could be zero).
//
//   bool erase_one(const Item& target)
//     Postcondition: If target was in the tbag, then one copy of target has
//     been removed from the tbag; otherwise the tbag is unchanged. A true
//     return value indicates that one copy was removed; false indicates that
//     nothing was removed.
//
//   void insert(const Item& entry) 
//     Postcondition: A new copy of entry has been inserted into the tbag.
//
//   void operator +=(const tbag& addend) 
//     Postcondition: Each item in addend has been added to this tbag.
//
// CONSTANT MEMBER FUNCTIONS for the tbag<Item> class:
//   size_type count(const Item& target) const 
//     Postcondition: Return value is number of times target is in the tbag.
//
//   Item grab( ) const 
//     Precondition: size( ) > 0.
//     Postcondition: The return value is a randomly selected item from the tbag.
//
//   size_type size( ) const 
//     Postcondition: Return value is the total number of items in the tbag.

#ifndef KELVEN_SOE_TBAG_H
#define KELVEN_SOE_TBAG_H
#include <cstdlib>   // Provides NULL and size_t and NULL
#include "tnode.h"   // Provides tnode class

namespace kelven_soe
{
    template <class Item>
    class tbag
    {
    public:
        // TYPEDEFS
	typedef std::size_t size_type;
        typedef Item value_type;
	
        // CONSTRUCTORS and DESTRUCTOR
        tbag( );
        tbag(const tbag& source);
        ~tbag( );
	
        // MODIFICATION MEMBER FUNCTIONS
        size_type erase(const Item& target);
        bool erase_one(const Item& target);
        void insert(const Item& entry);
        void operator +=(const tbag& addend);
        void operator =(const tbag& source);
	
        // CONST MEMBER FUNCTIONS
        size_type count(const Item& target) const;
        Item grab( ) const;
        size_type size( ) const { return many_tnodes; }

    private:
        tnode<Item> *head_ptr;        // Head pointer for the list of items
        size_type many_tnodes;        // Number of tnodes on the list
    };

    // NONMEMBER functions for the tbag
    template <class Item>
    tbag<Item> operator +(const tbag<Item>& b1, const tbag<Item>& b2);
}

// The implementation of a template class must be included in its header file:
#include "tbag.template"
#endif

