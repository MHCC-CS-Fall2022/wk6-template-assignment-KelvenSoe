// FILE: testTbag.cxx
// AUTHOR: Kelven Soe
// Summary: Test file for the tbag class

#include <iostream> // provides cout and endl
#include "tbag.h" // provides functions from tbag and tnode
#include <cstdlib> // provides EXIT_SUCCESS
using namespace std;
using namespace kelven_soe;

int main()
{
	tbag<int> b1;
	tbag<int> b2;
	int user_input;

	cout << "enter intergers you would like to put in tbag1...\n";
	for (int i = 0; i < 10; i++)
	{
		cin >> user_input;
		b1.insert(user_input);
	}
	
	cout << "enter intergers you would like to put in tbag2...\n";
	for (int i = 0; i < 10; i++)
	{
		cin >> user_input;
		b2.insert(user_input);
	}

	cout << "There are currently " << b1.size() << " intergers in the bag\n";

	cout << "I will extract the number 1 if there are any...\n";
	b1.erase(1);
	cout << "There are currently " << b1.count(1) << " 1s in the bag\n";

	cout << "I will proceed to remove a 7 if there are any...\n";
	int removed;
	removed = b1.erase_one(7);

	if(removed == 1)
	{
		cout << "Target number 7 has been neutralized\n";
	}
	else
	{
		cout << "Target number 7 has not been found\n";
	}

`	cout << "I will add the contents of b2 into b1 to combine the both...\n";
	cout << "b1 size before: " << b1.size() << endl;
	b1 += b2;
	cout << "b1 size after adding contents of b2: " << b1.size() << endl;
	
	cout << "making the contents of b2 equal to the contents of b1...\n";
	b2 = b1;
	cout << "The size of b2 is now the same size as b1...\n";
	cout << "The size of b2: " << b2.size();
	cout << "The size of b1: " << b1.size();
	
	cout << "I will select a random number from the tbag1 " << endl;
	cout << "Random number: " << b1.grab();
	
	tbag<int> b3;
	b3 = together(b1, b2);

	return EXIT_SUCCESS;

}

