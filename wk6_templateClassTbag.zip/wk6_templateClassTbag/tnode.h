// FILE: ttnode.h (part of the namespace main_savitch_6B)
// AUTHOR: Kelven Soe
// PROVIDES: A template class for a tnode in a linked list, and list manipulation
// functions. The template parameter is the type of the data in each tnode.
//
// TYPEDEF for the tnode<Item> template class:
//   Each tnode of the list contains a piece of data and a pointer to the
//   next tnode. The type of the data (tnode<Item>::value_type) is the Item type
//   from the template parameter. The type may be any of the built-in C++ classes
//   (int, char, ...) or a class with a default constructor, an assignment
//   operator, and a test for equality (x == y).
// NOTE:
//   Many compilers require the use of the new keyword typename before using
//   the expression tnode<Item>::value_type. Otherwise
//   the compiler doesn't have enough information to realize that it is the
//   name of a data type.
//
// CONSTRUCTOR for the tnode<Item> class:
//   tnode(
//     const Item& init_data = Item(),
//     tnode* init_link = NULL
//   )
//     Postcondition: The tnode contains the specified data and link.
//     NOTE: The default value for the init_data is obtained from the default
//     constructor of the Item. In the ANSI/ISO standard, this notation
//     is also allowed for the built-in types, providing a default value of
//     zero. The init_link has a default value of NULL.
//
// NOTE about two versions of some functions:
//   The data function returns a reference to the data field of a tnode and
//   the link function returns a copy of the link field of a tnode.
//   Each of these functions comes in two versions: a const version and a
//   non-const version. If the function is activated by a const tnode, then the
//   compiler choses the const version (and the return value is const).
//   If the function is activated by a non-const tnode, then the compiler choses
//   the non-const version (and the return value will be non-const).
// EXAMPLES:
//    const tnode<int> *c;
//    c->link( ) activates the const version of link returning const tnode*
//    c->data( ) activates the const version of data returning const Item&
//    c->data( ) = 42; ... is forbidden
//    tnode<int> *p;
//    p->link( ) activates the non-const version of link returning tnode*
//    p->data( ) activates the non-const version of data returning Item&
//    p->data( ) = 42; ... actually changes the data in p's tnode
//
// MEMBER FUNCTIONS for the tnode<Item> class:
//   const Item& data( ) const <----- const version
//   and
//   Item& data( ) <----------------- non-const version
//   See the note (above) about the const version and non-const versions:
//     Postcondition: The return value is a reference to the  data from this tnode.
//
//   const tnode* link( ) const <----- const version
//   and
//   tnode* link( ) <----------------- non-const version
//   See the note (above) about the const version and non-const versions:
//     Postcondition: The return value is the link from this tnode.
//   
//   void set_data(const Item& new_data)
//     Postcondition: The tnode now contains the specified new data.
//   
//   void set_link(tnode* new_link)
//     Postcondition: The tnode now contains the specified new link.
//
// FUNCTIONS in the linked list toolkit:
//   template <class Item>
//   void list_clear(tnode<Item>*& head_ptr) 
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: All tnodes of the list have been returned to the heap,
//     and the head_ptr is now NULL.
//
//   template <class Item>
//   void list_copy
//   (const tnode<Item>* source_ptr, tnode<Item>*& head_ptr, tnode<Item>*& tail_ptr)
//     Precondition: source_ptr is the head pointer of a linked list.
//     Postcondition: head_ptr and tail_ptr are the head and tail pointers for
//     a new list that contains the same items as the list pointed to by
//     source_ptr. The original list is unaltered.
//
//   template <class Item>
//   void list_head_insert(tnode<Item>*& head_ptr, const Item& entry) 
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: A new tnode containing the given entry has been added at
//     the head of the linked list; head_ptr now points to the head of the new,
//     longer linked list.
//
//   template <class Item>
//   void list_head_remove(tnode<Item>*& head_ptr) 
//     Precondition: head_ptr is the head pointer of a linked list, with at
//     least one tnode.
//     Postcondition: The head tnode has been removed and returned to the heap;
//     head_ptr is now the head pointer of the new, shorter linked list.
//
//   template <class Item>
//   void list_insert(tnode<Item>* previous_ptr, const Item& entry) 
//     Precondition: previous_ptr points to a tnode in a linked list.
//     Postcondition: A new tnode containing the given entry has been added
//     after the tnode that previous_ptr points to.
//
//   template <class Item>
//   size_t list_length(const tnode<Item>* head_ptr)
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: The value returned is the number of tnodes in the linked
//     list.
//
//   template <class tnodePtr, class SizeType>
//   tnodePtr list_locate(tnodePtr head_ptr, SizeType position)
//   The tnodePtr may be either tnode<Item>* or const tnode<Item>*
//     Precondition: head_ptr is the head pointer of a linked list, and
//     position > 0.
//     Postcondition: The return value is a pointer that points to the tnode at
//     the specified position in the list. (The head tnode is position 1, the
//     next tnode is position 2, and so on). If there is no such position, then
//     the null pointer is returned.
//
//   template <class Item>
//   void list_remove(tnode<Item>* previous_ptr) 
//     Precondition: previous_ptr points to a tnode in a linked list, and this
//     is not the tail tnode of the list.
//     Postcondition: The tnode after previous_ptr has been removed from the
//     linked list.
//
//   template <class tnodePtr, class Item>
//   tnodePtr list_search
//   (tnodePtr head_ptr, const Item& target) 
//   The tnodePtr may be either tnode<Item>* or const tnode<Item>*
//     Precondition: head_ptr is the head pointer of a linked list.
//     Postcondition: The return value is a pointer that points to the first
//     tnode containing the specified target in its data member. If there is no
//     such tnode, the null pointer is returned.
//
// DYNAMIC MEMORY usage by the toolkit: 
//   If there is insufficient dynamic memory, then the following functions throw
//   bad_alloc: the constructor, list_head_insert, list_insert, list_copy.

#ifndef KELVEN_SOE_TNODE_H  
#define KELVEN_SOE_TNODE_H
#include <cstdlib>   // Provides NULL and size_t

namespace kelven_soe
{
    template <class Item>
    class tnode
    {
    public:
        // TYPEDEF
        typedef Item value_type;
        // CONSTRUCTOR
        tnode(const Item& init_data=Item( ), tnode* init_link=NULL)
            { data_field = init_data; link_field = init_link; }
        // MODIFICATION MEMBER FUNCTIONS
        Item& data( ) { return data_field; }
        tnode* link( ) { return link_field; }
        void set_data(const Item& new_data) { data_field = new_data; }
        void set_link(tnode* new_link) { link_field = new_link; }
        // CONST MEMBER FUNCTIONS
        const Item& data( ) const { return data_field; }
        const tnode* link( ) const { return link_field; }
    private:
        Item data_field;
        tnode *link_field;
    };

    // FUNCTIONS to manipulate a linked list:
    template <class Item>
    void list_clear(tnode<Item>*& head_ptr);

    template <class Item>
    void list_copy
        (const tnode<Item>* source_ptr, tnode<Item>*& head_ptr, tnode<Item>*& tail_ptr);

    template <class Item>
    void list_head_insert(tnode<Item>*& head_ptr, const Item& entry); 

    template <class Item>
    void list_head_remove(tnode<Item>*& head_ptr);

    template <class Item>
    void list_insert(tnode<Item>* previous_ptr, const Item& entry);
 
    template <class Item>
	std::size_t list_length(const tnode<Item>* head_ptr);

    template <class tnodePtr, class SizeType>
    tnodePtr list_locate(tnodePtr head_ptr, SizeType position);

    template <class Item>
    void list_remove(tnode<Item>* previous_ptr);
   
    template <class tnodePtr, class Item>
    tnodePtr list_search(tnodePtr head_ptr, const Item& target);

};

#include "tnode.template"
#endif
